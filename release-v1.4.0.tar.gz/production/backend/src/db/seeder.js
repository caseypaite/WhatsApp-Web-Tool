require("dotenv").config();const{Client}=require("pg"),bcrypt=require("bcryptjs"),seedAdmin=async()=>{const e=new Client({connectionString:process.env.DATABASE_URL});try{await e.connect(),console.log("Connected to database for seeding...");const s=process.env.INITIAL_ADMIN_EMAIL,o=process.env.INITIAL_ADMIN_PASSWORD,t=await bcrypt.hash(o,10);if(!s||!o)throw new Error("INITIAL_ADMIN_EMAIL or INITIAL_ADMIN_PASSWORD not set in .env");const a=await e.query("SELECT id FROM roles WHERE name = 'Admin'");if(a.rows.length===0)throw new Error("Admin role not found in roles table. Please run the schema script first.");const r=a.rows[0].id,n=(await e.query(`INSERT INTO users (email, password, name, status) 
       VALUES ($1, $2, $3, $4) 
       ON CONFLICT (email) DO UPDATE SET password = EXCLUDED.password, status = EXCLUDED.status
       RETURNING id`,[s,t,"Super Admin","ACTIVE"])).rows[0].id;await e.query(`INSERT INTO user_roles (user_id, role_id) 
       VALUES ($1, $2) 
       ON CONFLICT DO NOTHING`,[n,r]),await e.query(`INSERT INTO landing_page_config (hero_text, cta_text, image_url)
       VALUES ($1, $2, $3)
       ON CONFLICT DO NOTHING`,["Welcome to AppStack","Get Started","https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=2832"]),await e.query(`INSERT INTO system_settings (key, value)
       VALUES ($1, $2), ($3, $4), ($5, $6), ($7, $8), ($9, $10)
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,["site_name","WhatsApp Web Tool","ai_enabled","false","ai_provider","gemini","ai_custom_prompt","You are a helpful community assistant for WhatsApp Web Tool. Keep responses concise and professional.","ai_model","gemini-1.5-flash"]),console.log(`Super Admin seeded successfully: ${s}`)}catch(s){console.error("Error seeding admin:",s.message)}finally{await e.end()}};seedAdmin();
